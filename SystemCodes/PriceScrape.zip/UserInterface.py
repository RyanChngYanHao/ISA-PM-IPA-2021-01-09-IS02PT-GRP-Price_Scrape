# User Interface
import os
import tkinter as tk
#import tkinter.font as tkf
from tkinter import messagebox
from PIL import ImageTk, Image

root = tk.Tk()
root.title('<<Price Scrape>>')

# Browser Top Left Icon
root.iconbitmap('./img/ProjectIcon.ico')
# Window size
root.geometry('640x640+100+100')

# 0. Project Image
my_img = ImageTk.PhotoImage(Image.open('./img/ProjectImg.jpg'))
my_img_label = tk.Label(image=my_img)
my_img_label.place(x=15, y=15)

# 1. Main Frame
Main = tk.LabelFrame(root, text='<<Price Scrape>>', padx=10, pady=10, width=300, height=300)
Main.place(x=320, y=320)

lbl1 = tk.Label(Main, text = '<< Welcome to Price Scrape! >>', 
                font = ("Arial Bold", 12)).place(x=19, y=10)
lbl2 = tk.Label(Main, text = 'Bought to you by:').place(x=50, y=225)
lbl3 = tk.Label(Main, text = 'Chng Yan Hao / Lim Kah Ghi').place(x=70, y=245)

## 5 buttons 5 functions
def runScrape():
    ans = messagebox.askyesno(title='<Run Scrape Now>', 
                              message='Do you want to continue?')
    print(ans)
    if ans == 1:
        os.system('python PriceScrape.py')
        messagebox.showinfo('<Run Scrape Now>', "Completed!")
        
def runSchedule():    
    popup = tk.Tk()
    popup.title('Daily Scheduler')
    popup.iconbitmap('./img/ProjectIcon.ico')
    popup.geometry('300x40+260+300')
    inputBox = tk.Entry(popup)
    inputBox.insert(0, '08:00')
    inputBox.pack()
    inputBox.focus_set()
    def callback():        
        userhhmm = inputBox.get()
        if os.path.isfile('hhmm.txt'):
            os.remove('./hhmm.txt')        
        tmptext = open('hhmm.txt', 'w')
        tmptext.write('hhmm = "' + userhhmm + '"')
        tmptext.close()        
        print('\n')
        print('Scheduler: daily time set to ' + userhhmm)
        import DailyScheduler        
        popup.destroy()
    questionBtn = tk.Button(popup, text = 'Enter daily timer "hh:mm"', command = callback)
    questionBtn.pack()
    popup.mainloop()
    
def setItemQuery():
    if os.path.isfile('item_Query.txt'):
        os.system('item_Query.txt')
    else:
        import DefaultQuery
        os.system('item_Query.txt')
    
def setSelectors():
    if os.path.isfile('adv_Setting.txt'):
        os.system('adv_Setting.txt')
    else:
        import DefaultSetting
        os.system('adv_Setting.txt')
        
def setDefault():
    ans = messagebox.askyesno(title='Restore to Default', message='Do you want to continue?')
    print(ans)
    if ans == 1:
        from datetime import datetime
        if not os.path.exists('output'):
            os.mkdir('output')       
        now = datetime.now()            
        timestamp = now.strftime('%Y%m%d-%H%M')
        if os.path.isfile('item_Query.txt'):
            os.rename('./item_Query.txt', './output/item_Query_' + timestamp + '.txt')
            import DefaultQuery
            print('\n')
            print('Old item_Query.txt has been backup in output folder.')
        else:
            import DefaultQuery
        if os.path.isfile('adv_Setting.txt'):
            os.rename('./adv_Setting.txt', './output/adv_Setting.txt_' + timestamp + '.txt')
            import DefaultSetting
            print('\n')
            print('Old adv_Setting.txt has been backup in output folder.')
        else:
            import DefaultSetting
           
btn0 = tk.Button(Main, text='<Run Scrape Now>', command=runScrape).place(x=20, y=50)
btn1 = tk.Button(Main, text='<Schedule Later>', command=runSchedule).place(x=155, y=50)

## 1.1 Setting Frame
Setting = tk.LabelFrame(Main, text='<<Setting>>', width=240, height=140)
Setting.place(x=20, y=80)
btn2 = tk.Button(Setting, text='Item Query Listing', command=setItemQuery).place(x=70, y=10)
btn3 = tk.Button(Setting, text='Stores & Selectors', command=setSelectors).place(x=70, y=50)
btn4 = tk.Button(Setting, text='Restore to Default', command=setDefault).place(x=70, y=90)

root.mainloop()
