# Similarity Score
# With reference to: 
# https://www.geeksforgeeks.org/python-measure-similarity-between-two-sentences-using-cosine-similarity/

import re
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

def scorePhrases(phrase1, phrase2):
    
    # remove symbols
    phrase1 = re.sub(r'[^\w]', ' ', phrase1)
    phrase2 = re.sub(r'[^\w]', ' ', phrase2)
        
    # tokenize the words
    token1 = word_tokenize(phrase1)
    token2 = word_tokenize(phrase2)
       
    # stopword lsit
    stopwordsEL = stopwords.words('english')
    
    # remove stopwords
    token1_nsw = {w for w in token1 if not w in stopwordsEL} 
    token2_nsw = {w for w in token2 if not w in stopwordsEL}
    
    # stem words (also convert to lowercase)
    PS = PorterStemmer()
    token1s = {PS.stem(w) for w in token1_nsw}
    token2s = {PS.stem(w) for w in token2_nsw}
    
    # set of union without stopwords
    token_union = token1s.union(token2s)
    
    # create vectors
    token1_vec = []
    token2_vec = []
    for w in token_union:
        if w in token1s:
            token1_vec.append(1)
        else:
            token1_vec.append(0)
        if w in token2s:
            token2_vec.append(1)
        else:
            token2_vec.append(0)
    
    # cosine formula
    ## numerator (dot product)
    n = 0
    for i in range(len(token_union)):
        n+= token1_vec[i] * token2_vec[i]
    ## denominator
    d = float(sum(token1_vec)**0.5 * sum(token2_vec)**0.5)
    cosineScore = round(n/d, 3)
    
    return cosineScore

