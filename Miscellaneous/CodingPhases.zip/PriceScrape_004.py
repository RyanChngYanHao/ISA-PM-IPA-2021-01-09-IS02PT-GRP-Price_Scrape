# Price Scrape 20210401
# exec(open('PriceScrape_004.py').read())

# Task: 
    # 001 Open Url
    # 002 Click search bar, clear, type & enter
    # 003 Get 2nd item name, item price, countdown timer
    # 004 loop thru all items in 003, hover added

# set variables
store_Name = 'NTUC'
store_Url = 'https://www.fairprice.com.sg'
store_SearchBar = '//input[@id="search-input-bar"]'
item_Name_Selector_List = '//div[@class="sc-1plwklf-7 jibnUN"]/span[@class="sc-1bsd7ul-1 gGWxuk"]'
item_Price_Selector_List = '//span[@class="sc-1bsd7ul-1 hiLGVO"]/span[@class="sc-1bsd7ul-1 gJhHzP"]'

# start
import tagui as t

t.init()

t.url(store_Url)

t.click(store_SearchBar)
t.type(store_SearchBar, '[clear]')
t.type(store_SearchBar, 'China Apple')
t.type(store_SearchBar, '[enter]')

t.wait(5)
num_Item = t.count(item_Name_Selector_List)
print(f'{num_Item} items found in page')

# 004 loop thru all items in 003, hover added
for i in range(1, num_Item + 1):
    item_Name_Selector = f'({item_Name_Selector_List})[{i}]'
    item_Price_Selector = f'({item_Price_Selector_List})[{i}]'
    t.hover(item_Name_Selector)
    item_Name = t.read(item_Name_Selector)
    t.hover(item_Price_Selector)
    item_Price = t.read(item_Price_Selector)
    
    print('\n')
    print('Store Name:  ' + store_Name)
    print('Item Name:   ' + item_Name)
    print('Item Price:  ' + item_Price)
    
print('\n')
for j in range(5, 0, -1):
    print('Closing in ' + str(j) + 's')
    t.wait(1)
    
t.close()

