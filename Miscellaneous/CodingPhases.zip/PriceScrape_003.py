# Price Scrape 20210401
# exec(open('PriceScrape_003.py').read())

# Task: 
    # 001 Open Url
    # 002 Click search bar, clear, type & enter
    # 003 Get 2nd item name, item price, countdown timer

# set variables
store_Name = 'NTUC'
store_Url = 'https://www.fairprice.com.sg'
store_SearchBar = '//input[@id="search-input-bar"]'
item_Name_Selector = f'(//div[@class="sc-1plwklf-7 jibnUN"]/span[@class="sc-1bsd7ul-1 gGWxuk"])[2]'
item_Price_Selector = f'(//span[@class="sc-1bsd7ul-1 hiLGVO"]/span[@class="sc-1bsd7ul-1 gJhHzP"])[2]'

# start
import tagui as t

t.init()

t.url(store_Url)

t.click(store_SearchBar)
t.type(store_SearchBar, '[clear]')
t.type(store_SearchBar, 'China Apple')
t.type(store_SearchBar, '[enter]')

# 003 Get 2nd item name, item price
t.wait(5)
item_Name = t.read(item_Name_Selector)
item_Price = t.read(item_Price_Selector)

print('\n')
print('Store Name:  ' + store_Name)
print('Item Name:   ' + item_Name)
print('Item Price:  ' + item_Price)
print('\n')
for i in range(5, 0, -1):
    print('Closing in ' + str(i) + 's')
    t.wait(1)
    
t.close()

