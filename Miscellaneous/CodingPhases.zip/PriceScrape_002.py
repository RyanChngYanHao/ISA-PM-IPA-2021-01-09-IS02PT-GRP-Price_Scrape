# Price Scrape 20210401
# exec(open('PriceScrape_002.py').read())

# Task: 
    # 001 Open Url
    # 002 Click search bar, clear, type & enter

# set variables
store_Name = 'NTUC'
store_Url = 'https://www.fairprice.com.sg'
store_SearchBar = '//input[@id="search-input-bar"]'

import tagui as t

t.init()

t.url(store_Url)
print('Store Name: ' + store_Name)

# 002 Click search bar, clear, type & enter
t.click(store_SearchBar)
t.type(store_SearchBar, '[clear]')
t.type(store_SearchBar, 'China Apple')
t.type(store_SearchBar, '[enter]')


print('Price Scrape closing in 5 secs')
t.wait(5)
t.close()

