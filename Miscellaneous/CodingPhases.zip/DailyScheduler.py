# Scheduler
import schedule
import time
import os

def job():
    print('\n')
    print("I'm working...")
    os.system('python PriceScrape.py')

if os.path.isfile('hhmm.txt'):
    exec(open('hhmm.txt').read())
    print('Do not close this "CMD window"/"Price Scrape GUI" for scheduler to remain working.')
    # schedule.every().day.at(hhmm).do(job)
    schedule.every(25).seconds.do(job)

    while True:
        schedule.run_pending()
        time.sleep(1)
else:
    print('Daily time not set / wrongly set.')


