# Default Query
print ('File "item_Query.txt" does not exist...')
default = open('item_Query.txt', 'w')
default.write("item_Query = ['Philippines Banana', 'Australia Carrot', 'China Apple']")
default.close()
print ('New item_Query.txt created...')


