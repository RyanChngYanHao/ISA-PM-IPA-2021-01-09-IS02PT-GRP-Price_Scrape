# Price Scrape 20210401
# exec(open('PriceScrape_017.py').read())

# Task: 
    # 001 Open Url
    # 002 Click search bar, clear, type & enter
    # 003 Get 2nd item name, item price, countdown timer
    # 004 loop thru all items in 003, hover added
    # 005** Guess last item on page, helper function & checks
    # 006** Make price selectors relative to name
    # 007 Get unit, lower timeout threshold, edit pageLastRef
    # 008 Get avalability
    # 009 More than 1 query
    # 010 Set threshold for number of items
    # 011 Add similarity score
    # 012 Modularize item query
    # 013 Modularize other variables
    # 014 Save file
    # 015 Time stamp, Output folder, Smart Sort
    # 016 Solve 1: Cannot find item, rework locate_SelectorQuit to locate_Selector
    #     Solve 2: Strings with additional white spaces
    #     Solve 3: Inconsitent Item Availability convention
    # 017 Multiple stores, corrected some variable setting @ locate_Selector, corrected pageLastRef not found
    
import tagui as t
import pandas as pd
import os
from datetime import datetime
import SimilarityScore as SS  

###### Initial Setup ######
# import 'item_Query list' and 'list of objects of store variables'
try:
    exec(open('item_Query.txt').read())    
except:
    print ('File "item_Query.txt" does not exist...')
    new = open('item_Query.txt', 'w')
    # default list
    new.write("item_Query = ['Philippines Banana', 'Australia Carrot', 'China Apple']")
    new.close()
    print ('New item_Query.txt created...')
    exec(open('item_Query.txt').read())
    # returns varaiable item_Query, list

try:   
    exec(open('adv_Setting.txt').read())
except:
    import DefaultSetting
    exec(open('adv_Setting.txt').read())
    # returns adv_Setting, list of obj

# helper functions
def exitIn5():    
    print('\n')
    print('Scrape ended')
    for j in range(5, 0, -1):
        print('Closing browser in ' + str(j) + 's...')
        t.wait(1)    
    t.close()
    
def locate_Selector(selector, wait_time = 7):
    print('\n')
    wait_status = 0
    for loop_wait in range(1, wait_time):
        if t.present(selector):
            wait_status = 1
            break
        else:
            timeOut = wait_time - loop_wait
            print(f'Timeout if {selector} not found in {timeOut}s')
            t.wait(1)
    if (wait_status==0):
        print('Selector ' + selector + ' not found')
        # exitIn5()        
    else:
        t.hover(selector)
    return wait_status

def read_SelectorNil(selector, wait_time = 2):
    wait_status = 0
    for loop_wait in range(1, wait_time):
        if t.present(selector):
            wait_status = 1
            break
        else:
            t.wait(1)
    if (wait_status==0):
        text = 'NA'
    else:
        t.hover(selector)
        text = t.read(selector)
    return text

# define output
output = pd.DataFrame(columns=('Item Query No.', 'Item Query', 'Store Name',
                               'Item Name', 'Item Price', 'Item Unit',
                               'Item Availability', 'Item Similarity'))

###### End of Initial Setup ######

###### Scraping and Loops ######
t.init()
## Main loop (loop thru stores)
for obj in adv_Setting:
    if len(obj) == 10:
        store_Name                 = list(obj.values())[0]
        store_Url                  = list(obj.values())[1]
        store_SearchBar            = list(obj.values())[2]
        item_Name_Selector_List    = list(obj.values())[3]
        rel_Item_Price_Selector    = list(obj.values())[4]
        rel_Item_Unit_Selector     = list(obj.values())[5]
        rel_Item_Avail_Selector    = list(obj.values())[6] 
        page_LastRef               = list(obj.values())[7]
        timeOutThreshold           = list(obj.values())[8]
        itemCountThreshold         = list(obj.values())[9] 
        
        # start        
        t.url(store_Url)
        if locate_Selector(store_SearchBar, timeOutThreshold):
            ### Sub loop (loop thru item_Query)
            for q in range(len(item_Query)):
                item_QueryNo = str(q + 1)
                t.click(store_SearchBar)
                t.type(store_SearchBar, '[clear]')
                t.type(store_SearchBar, item_Query[q])
                t.type(store_SearchBar, '[enter]')
                t.wait(timeOutThreshold)
                
                if (locate_Selector(page_LastRef, timeOutThreshold) and
                locate_Selector(item_Name_Selector_List, timeOutThreshold)):
                    # happy path
                    num_Item = t.count(item_Name_Selector_List)
                    n = min(num_Item, itemCountThreshold)
                    print('\n')
                    print(f'Retrieving {n} items found on first page for <<{item_Query[q]}>>:')
                    
                    #### Sub Sub loop (loop thru found items)
                    for i in range(1, n + 1):
                        item_Name_Selector = f'({item_Name_Selector_List})[{i}]'
                        item_Price_Selector = f'({item_Name_Selector_List})[{i}]{rel_Item_Price_Selector}'
                        item_Unit_Selector = f'({item_Name_Selector_List})[{i}]{rel_Item_Unit_Selector}'
                        item_Avail_Selector = f'({item_Name_Selector_List})[{i}]{rel_Item_Avail_Selector}'
                        
                        item_Name = read_SelectorNil(item_Name_Selector)    
                        item_Price = read_SelectorNil(item_Price_Selector)
                        item_Unit = read_SelectorNil(item_Unit_Selector)
                        # find out-of-stock
                        if t.present(item_Avail_Selector):
                            item_Avail = 'Not Available'
                        else:
                            item_Avail = 'Available'
                        
                        # clear additional white spaces
                        item_Name = ' '.join(item_Name.split())
                        item_Price = ' '.join(item_Price.split())
                        item_Unit = ' '.join(item_Unit.split())                
                        
                        print('\n')
                        print(f'{i}.')            
                        print('Item Query No.:      ' + item_QueryNo)
                        print('Item Query:          ' + item_Query[q])
                        print('Store Name:          ' + store_Name)
                        print('Item Name:           ' + item_Name)
                        print('Item Price:          ' + item_Price)
                        print('Item Unit:           ' + item_Unit)
                        print('Item Availability:   ' + item_Avail)
                        
                        item_Score = str(SS.scorePhrases(item_Query[q], item_Name))
                        print('*Item Similarity:    ' + item_Score)
                        
                        scrapeData = {'Item Query No.':item_QueryNo, 
                                      'Item Query':item_Query[q], 
                                      'Store Name':store_Name,
                                      'Item Name':item_Name, 
                                      'Item Price':item_Price, 
                                      'Item Unit':item_Unit,
                                      'Item Availability':item_Avail, 
                                      'Item Similarity':item_Score}
                        output = output.append(scrapeData, ignore_index=True)
                else:
                        # null entry
                        scrapeData = {'Item Query No.':item_QueryNo, 
                                      'Item Query':item_Query[q], 
                                      'Store Name':store_Name,
                                      'Item Name':'', 
                                      'Item Price':'', 
                                      'Item Unit':'',
                                      'Item Availability':'', 
                                      'Item Similarity':''}
                output = output.append(scrapeData, ignore_index=True)
###### End of Scraping and Loops ######

###### Remarks, Output and Exit ######           
# remarks & export csv        
print('\n')       
print('* - generated by internal algorithm, not scraped.')
if not os.path.exists('output'):
	os.mkdir('output')       
now = datetime.now()
timestamp = now.strftime('%Y%m%d-%H%M')      
filename = 'ScrapedTbl_' + timestamp + '.csv'
## sort, most relevant first
output['nSimilarity'] = 1 - pd.to_numeric(output['Item Similarity'])
output = output.sort_values(by=['Item Query No.', 'Item Availability', 'nSimilarity', 'Item Price', 'Item Name'])
output.drop('nSimilarity', 1, inplace=True)
output.to_csv('output/' + filename, index = False)
print(f'Collect data saved as {filename}')
    
exitIn5()
###### End ######    







