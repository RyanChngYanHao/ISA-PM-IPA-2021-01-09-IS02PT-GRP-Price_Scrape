# Price Scrape 20210401
# exec(open('PriceScrape_005.py').read())

# Task: 
    # 001 Open Url
    # 002 Click search bar, clear, type & enter
    # 003 Get 2nd item name, item price, countdown timer
    # 004 loop thru all items in 003, hover added
    # 005** Guess last item on page, helper function & checks

# set variables
store_Name                 = 'NTUC'
store_Url                  = 'https://www.fairprice.com.sg'
store_SearchBar            = '//input[@id="search-input-bar"]'
item_Name_Selector_List    = '//div[@class="sc-1plwklf-7 jibnUN"]/span[@class="sc-1bsd7ul-1 gGWxuk"]'
item_Price_Selector_List   = '//span[@class="sc-1bsd7ul-1 hiLGVO"]/span[@class="sc-1bsd7ul-1 gJhHzP"]'
page_LastRef               = '//div[@class="blu064-16 efNTQy"]'
timeOutThreshold           = 10

# helper functions
def exitIn5():    
    print('\n')
    for j in range(5, 0, -1):
        print('Closing in ' + str(j) + 's')
        t.wait(1)    
    t.close()
    
def locate_SelectorQuit(selector, wait_time = timeOutThreshold):
    wait_status = 0
    for loop_wait in range(1, wait_time):
        if t.present(selector):
            wait_status = 1
            break
        else:
            timeOut = timeOutThreshold - loop_wait
            print(f'Timeout if {selector} not found in {timeOut}s')
            t.wait(1)
    if (wait_status==0):
        print('Selector ' + selector + ' not found')
        exitIn5()        
    else:
        t.hover(selector)
    return

def read_SelectorNil(selector, wait_time = 5):
    wait_status = 0
    for loop_wait in range(1, wait_time):
        if t.present(selector):
            wait_status = 1
            break
        else:
            t.wait(1)
    if (wait_status==0):
        text = 'NA'
    else:
        t.hover(selector)
        text = t.read(selector)
    return text

# start
import tagui as t

t.init()

t.url(store_Url)

locate_SelectorQuit(store_SearchBar) # 005
t.click(store_SearchBar)
t.type(store_SearchBar, '[clear]')
t.type(store_SearchBar, 'China Apple')
t.type(store_SearchBar, '[enter]')
t.wait(3) # 005 giving sometime to load

locate_SelectorQuit(page_LastRef) # 005
locate_SelectorQuit(item_Name_Selector_List) # 005
num_Item = t.count(item_Name_Selector_List)
print(f'{num_Item} items found in page')

for i in range(1, num_Item + 1):
    item_Name_Selector = f'({item_Name_Selector_List})[{i}]'
    item_Price_Selector = f'({item_Price_Selector_List})[{i}]'    
    
    item_Name = read_SelectorNil(item_Name_Selector)    
    item_Price = read_SelectorNil(item_Price_Selector)
    
    print('\n')
    print(f'{i}.')
    print('Store Name:  ' + store_Name)
    print('Item Name:   ' + item_Name)
    print('Item Price:  ' + item_Price)

exitIn5() # 005