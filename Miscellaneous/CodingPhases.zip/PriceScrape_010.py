# Price Scrape 20210401
# exec(open('PriceScrape_010.py').read())

# Task: 
    # 001 Open Url
    # 002 Click search bar, clear, type & enter
    # 003 Get 2nd item name, item price, countdown timer
    # 004 loop thru all items in 003, hover added
    # 005** Guess last item on page, helper function & checks
    # 006** Make price selectors relative to name
    # 007 Get unit, lower timeout threshold, edit pageLastRef
    # 008 Get avalability
    # 009 More than 1 query
    # 010 Set threshold for number of items    

# set variables
item_Query                 = ['Philippines Banana', 'Australia Carrot']
store_Name                 = 'NTUC'
store_Url                  = 'https://www.fairprice.com.sg'
store_SearchBar            = '//input[@id="search-input-bar"]'
item_Name_Selector_List    = '//div[@class="sc-1plwklf-7 jibnUN"]/span[@class="sc-1bsd7ul-1 gGWxuk"]'
rel_Item_Price_Selector    = '/ancestor::div[@class="sc-1plwklf-7 jibnUN"]/ancestor::div[@class="sc-1plwklf-8 jQmMcy"]/div/div/span[@class="sc-1bsd7ul-1 hiLGVO"]'
rel_Item_Unit_Selector     = '/ancestor::div[@class="sc-1plwklf-7 jibnUN"]/div/div/span[@class="sc-1bsd7ul-1 LLmwF"]'
rel_Item_Avail_Selector    = '/ancestor::div[@class="sc-1plwklf-7 jibnUN"]/ancestor::div[@class="sc-1plwklf-8 jQmMcy"]/ancestor::div[@data-testid="product"]/div/button[@data-testid="SvgAddToCart"]/span'
page_LastRef               = '//div[@class="blu064-15 ggTaxh"]'
timeOutThreshold           = 7
itemCountThreshold         = 20

# helper functions
def exitIn5():    
    print('\n')
    print('Scrape ended')
    for j in range(5, 0, -1):
        print('Closing browser in ' + str(j) + 's...')
        t.wait(1)    
    t.close()
    
def locate_SelectorQuit(selector, wait_time = timeOutThreshold):
    wait_status = 0
    for loop_wait in range(1, wait_time):
        if t.present(selector):
            wait_status = 1
            break
        else:
            timeOut = timeOutThreshold - loop_wait
            print(f'Timeout if {selector} not found in {timeOut}s')
            t.wait(1)
    if (wait_status==0):
        print('Selector ' + selector + ' not found')
        exitIn5()        
    else:
        t.hover(selector)
    return

def read_SelectorNil(selector, wait_time = 2):
    wait_status = 0
    for loop_wait in range(1, wait_time):
        if t.present(selector):
            wait_status = 1
            break
        else:
            t.wait(1)
    if (wait_status==0):
        text = 'NA'
    else:
        t.hover(selector)
        text = t.read(selector)
    return text

# start
import tagui as t

t.init()

t.url(store_Url)

locate_SelectorQuit(store_SearchBar)
# 010 Set threshold item
for q in range(len(item_Query)):
    t.click(store_SearchBar)
    t.type(store_SearchBar, '[clear]')
    t.type(store_SearchBar, item_Query[q])
    t.type(store_SearchBar, '[enter]')
    t.wait(timeOutThreshold)
    
    locate_SelectorQuit(page_LastRef)
    locate_SelectorQuit(item_Name_Selector_List)
    num_Item = t.count(item_Name_Selector_List)
    n = min(num_Item, itemCountThreshold)
    print('\n')
    print(f'Retrieving {n} items found on first page for <<{item_Query[q]}>>:')
    
    for i in range(1, n + 1):
        item_Name_Selector = f'({item_Name_Selector_List})[{i}]'
        item_Price_Selector = f'({item_Name_Selector_List})[{i}]{rel_Item_Price_Selector}'
        item_Unit_Selector = f'({item_Name_Selector_List})[{i}]{rel_Item_Unit_Selector}'
        item_Avail_Selector = f'({item_Name_Selector_List})[{i}]{rel_Item_Avail_Selector}'
        
        item_Name = read_SelectorNil(item_Name_Selector)    
        item_Price = read_SelectorNil(item_Price_Selector)
        item_Unit = read_SelectorNil(item_Unit_Selector)
        item_Avail = read_SelectorNil(item_Avail_Selector)
        
        print('\n')
        print(f'{i}.')
        item_QueryNo = str(q + 1)
        print('Item Query No.:      ' + item_QueryNo)
        print('Item Query:          ' + item_Query[q])
        print('Store Name:          ' + store_Name)
        print('Item Name:           ' + item_Name)
        print('Item Price:          ' + item_Price)
        print('Item Unit:           ' + item_Unit)
        print('Item Availability:   ' + item_Avail)

exitIn5()