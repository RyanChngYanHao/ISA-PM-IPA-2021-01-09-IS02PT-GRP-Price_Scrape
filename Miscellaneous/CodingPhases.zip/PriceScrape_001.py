# Price Scrape 20210401
# exec(open('PriceScrape_001.py').read())

# Task: 
    # 001 Open Url

# set variables
store_Name = 'NTUC'
store_Url = 'https://www.fairprice.com.sg'

import tagui as t

t.init()

# 001 Open Url
t.url(store_Url)
print('Store Name: ' + store_Name)

print('Price Scrape closing in 5 secs')
t.wait(5)
t.close()

