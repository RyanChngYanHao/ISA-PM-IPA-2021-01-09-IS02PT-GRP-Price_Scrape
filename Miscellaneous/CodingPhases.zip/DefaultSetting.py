# Default Setting
print ('File "adv_Setting.txt" does not exist...')
default = open('adv_Setting.txt', 'w')
default.write('''
obj0 = {
'store_Name'                 : 'Sheng Siong',
'store_Url'                  : 'https://allforyou.sg/',
'store_SearchBar'            : '//input[@id="small-searchterms"]',
'item_Name_Selector_List'    : '//a[@class="prodnamelink"]/span[@itemprop="name"]',
'rel_Item_Price_Selector'    : '/ancestor::a/ancestor::div/ancestor::div[@class="caption"]/div[@class="price"]',
'rel_Item_Unit_Selector'     : '/ancestor::a/ancestor::div/ancestor::div[@class="caption"]/div/div[@class="prodnameoffer"]/span',
'rel_Item_Avail_Selector'    : '/ancestor::a/ancestor::div/ancestor::div[@class="caption"]/li/a[@disabled="disabled"]',
'page_LastRef'               : '//div[@class="pager"]',
'timeOutThreshold'           : 7,
'itemCountThreshold'         : 20
}

obj1 = {
'store_Name'                 : 'NTUC',
'store_Url'                  : 'https://www.fairprice.com.sg',
'store_SearchBar'            : '//input[@id="search-input-bar"]',
'item_Name_Selector_List'    : '//div[@class="sc-1plwklf-7 jibnUN"]/span[@class="sc-1bsd7ul-1 gGWxuk"]',
'rel_Item_Price_Selector'    : '/ancestor::div[@class="sc-1plwklf-7 jibnUN"]/ancestor::div[@class="sc-1plwklf-8 jQmMcy"]/div/div/span[@class="sc-1bsd7ul-1 hiLGVO"]',
'rel_Item_Unit_Selector'     : '/ancestor::div[@class="sc-1plwklf-7 jibnUN"]/div/div/span[@class="sc-1bsd7ul-1 LLmwF"]',
'rel_Item_Avail_Selector'    : '/ancestor::div[@class="sc-1plwklf-7 jibnUN"]/ancestor::div[@class="sc-1plwklf-8 jQmMcy"]/ancestor::div[@data-testid="product"]/div[@class="sc-1axwsmm-8 eZwTgp"]',
'page_LastRef'               : '//div[@class="blu064-15 ggTaxh"]',
'timeOutThreshold'           : 7,
'itemCountThreshold'         : 20
}

obj2 = {
'store_Name'                 : 'RedMart',
'store_Url'                  : 'https://redmart.lazada.sg/#home',
'store_SearchBar'            : '//input[@id="q"]',
'item_Name_Selector_List'    : '//h4[@class="RedmartProductCard-title"]',
'rel_Item_Price_Selector'    : '/ancestor::div[@class="RedmartProductCard-content"]/div/div[@class="RedmartProductCard-price sg"]',
'rel_Item_Unit_Selector'     : '/ancestor::div[@class="RedmartProductCard-content"]/div[@class="RedmartProductCard-weight"]',
'rel_Item_Avail_Selector'    : '/ancestor::div[@class="RedmartProductCard-content"]/ancestor::a[@class="RedmartProductCard-link"]/ancestor::div[@class="RedmartProductCard-container"]/div[class="AtcButton-container AtcButton-containerWithoutQtyOutOfStock"]',
'page_LastRef'               : '//div[@class="button-mod-box"]',
'timeOutThreshold'           : 7,
'itemCountThreshold'         : 20
}

obj3 = {
'store_Name'                 : 'ColdStorage',
'store_Url'                  : 'https://coldstorage.com.sg/',
'store_SearchBar'            : '//input[@id="searchbox"]',
'item_Name_Selector_List'    : '//div[@class="product_category_name"]',
'rel_Item_Price_Selector'    : '/ancestor::div[@class="product_detail"]/div[@class="product_price"]',
'rel_Item_Unit_Selector'     : '/ancestor::div[@class="product_detail"]/div[@class="product_desc"]/span[@class="size"]',
'rel_Item_Avail_Selector'    : '/ancestor::div[@class="product_detail"]/ancestor::a/ancestor::div[@class="product_box"]/div[class="btn btn-primary btn-out-of-stock"]',
'page_LastRef'               : '//div[@class="copyright text-center"]',
'timeOutThreshold'           : 7,
'itemCountThreshold'         : 20
}

obj4 = {}
obj5 = {}
obj6 = {}
obj7 = {}
obj8 = {}
obj9 = {}

adv_Setting = [obj0, obj1, obj2, obj3, obj4, obj5, obj6, obj7, obj8, obj9]
''')

default.close()
print ('New adv_Setting.txt created...')


