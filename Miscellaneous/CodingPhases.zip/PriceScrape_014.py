# Price Scrape 20210401
# exec(open('PriceScrape_014.py').read())

# Task: 
    # 001 Open Url
    # 002 Click search bar, clear, type & enter
    # 003 Get 2nd item name, item price, countdown timer
    # 004 loop thru all items in 003, hover added
    # 005** Guess last item on page, helper function & checks
    # 006** Make price selectors relative to name
    # 007 Get unit, lower timeout threshold, edit pageLastRef
    # 008 Get avalability
    # 009 More than 1 query
    # 010 Set threshold for number of items
    # 011 Add similarity score
    # 012 Modularize item query
    # 013 Modularize other variables
    # 014 Save file
    
import tagui as t
import pandas as pd
import SimilarityScore as SS  

# set variables
try:
    exec(open('item_Query.txt').read())    
except:
    print ('File "item_Query.txt" does not exist...')
    new = open('item_Query.txt', 'w')
    # default list
    new.write("item_Query = ['Australia Carrot', 'Philippines Banana', 'China Apple']")
    new.close()
    print ('New item_Query.txt created...')
    exec(open('item_Query.txt').read())
    # returns varaiable item_Query, list

try:   
    exec(open('adv_Setting.txt').read())
except:
    import DefaultSetting
    exec(open('adv_Setting.txt').read())
    # returns adv_Setting, list of obj

obj = adv_Setting[0]
store_Name                 = list(obj.values())[0]
store_Url                  = list(obj.values())[1]
store_SearchBar            = list(obj.values())[2]
item_Name_Selector_List    = list(obj.values())[3]
rel_Item_Price_Selector    = list(obj.values())[4]
rel_Item_Unit_Selector     = list(obj.values())[5]
rel_Item_Avail_Selector    = list(obj.values())[6] 
page_LastRef               = list(obj.values())[7]
timeOutThreshold           = list(obj.values())[8]
itemCountThreshold         = list(obj.values())[9] 

# define output
output = pd.DataFrame(columns=('Item Query No.', 'Item Query', 'Store Name',
                               'Item Name', 'Item Price', 'Item Unit',
                               'Item Availability', 'Item Similarity'))


# helper functions
def exitIn5():    
    print('\n')
    print('Scrape ended')
    for j in range(5, 0, -1):
        print('Closing browser in ' + str(j) + 's...')
        t.wait(1)    
    t.close()
    
def locate_SelectorQuit(selector, wait_time = timeOutThreshold):
    wait_status = 0
    for loop_wait in range(1, wait_time):
        if t.present(selector):
            wait_status = 1
            break
        else:
            timeOut = timeOutThreshold - loop_wait
            print(f'Timeout if {selector} not found in {timeOut}s')
            t.wait(1)
    if (wait_status==0):
        print('Selector ' + selector + ' not found')
        exitIn5()        
    else:
        t.hover(selector)
    return

def read_SelectorNil(selector, wait_time = 2):
    wait_status = 0
    for loop_wait in range(1, wait_time):
        if t.present(selector):
            wait_status = 1
            break
        else:
            t.wait(1)
    if (wait_status==0):
        text = 'NA'
    else:
        t.hover(selector)
        text = t.read(selector)
    return text

  
# start
t.init()

t.url(store_Url)

locate_SelectorQuit(store_SearchBar)
for q in range(len(item_Query)):
    t.click(store_SearchBar)
    t.type(store_SearchBar, '[clear]')
    t.type(store_SearchBar, item_Query[q])
    t.type(store_SearchBar, '[enter]')
    t.wait(timeOutThreshold)
    
    locate_SelectorQuit(page_LastRef)
    locate_SelectorQuit(item_Name_Selector_List)
    num_Item = t.count(item_Name_Selector_List)
    n = min(num_Item, itemCountThreshold)
    print('\n')
    print(f'Retrieving {n} items found on first page for <<{item_Query[q]}>>:')
    
    for i in range(1, n + 1):
        item_Name_Selector = f'({item_Name_Selector_List})[{i}]'
        item_Price_Selector = f'({item_Name_Selector_List})[{i}]{rel_Item_Price_Selector}'
        item_Unit_Selector = f'({item_Name_Selector_List})[{i}]{rel_Item_Unit_Selector}'
        item_Avail_Selector = f'({item_Name_Selector_List})[{i}]{rel_Item_Avail_Selector}'
        
        item_Name = read_SelectorNil(item_Name_Selector)    
        item_Price = read_SelectorNil(item_Price_Selector)
        item_Unit = read_SelectorNil(item_Unit_Selector)
        item_Avail = read_SelectorNil(item_Avail_Selector)
        
        print('\n')
        print(f'{i}.')
        item_QueryNo = str(q + 1)
        print('Item Query No.:      ' + item_QueryNo)
        print('Item Query:          ' + item_Query[q])
        print('Store Name:          ' + store_Name)
        print('Item Name:           ' + item_Name)
        print('Item Price:          ' + item_Price)
        print('Item Unit:           ' + item_Unit)
        print('Item Availability:   ' + item_Avail)
        
        item_Score = str(SS.scorePhrases(item_Query[q], item_Name))
        print('*Item Similarity:    ' + item_Score)
        
        scrapeData = {'Item Query No.':item_QueryNo, 
                      'Item Query':item_Query[q], 
                      'Store Name':store_Name,
                      'Item Name':item_Name, 
                      'Item Price':item_Price, 
                      'Item Unit':item_Unit,
                      'Item Availability':item_Avail, 
                      'Item Similarity':item_Score}
        output = output.append(scrapeData, ignore_index=True)
        
print('\n')       
print('* - generated by internal algorithm, not scraped.')
output.to_csv(r'output.csv', index = False) 
print('Collect data saved as output.csv')
exitIn5()